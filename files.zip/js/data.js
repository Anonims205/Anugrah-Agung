// data.js - mock data sederhana untuk pengembangan awal
window.RockFlow = window.RockFlow || {};
window.RockFlow.data = {
  stockMovement: {
    labels: (function(){
      // 12 hari contoh
      var arr = [];
      for(var i=11;i>=0;i--){
        var d = new Date();
        d.setDate(d.getDate()-i);
        arr.push(d.toLocaleDateString());
      }
      return arr;
    })(),
    values: [120,130,125,140,150,145,160,155,170,165,180,175]
  },
  products: [
    {sku:'SKU-E001', name:'Smartphone X10', stock:5, min:10, max:100},
    {sku:'SKU-E002', name:'Laptop Pro 15', stock:42, min:20, max:80},
    {sku:'SKU-F001', name:'Kemeja Casual', stock:12, min:15, max:150},
    {sku:'SKU-F002', name:'Sepatu Sneakers', stock:85, min:20, max:100},
    {sku:'SKU-H001', name:'Vitamin C 1000mg', stock:320, min:50, max:200}
  ]
};