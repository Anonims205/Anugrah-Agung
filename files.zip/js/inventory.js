// inventory.js - stub untuk halaman inventory
window.RockFlow = window.RockFlow || {};
(function(ns){
  ns.inventory = ns.inventory || {};

  ns.inventory.init = function(){
    // placeholder - tambahkan logika real-time / polling di sini
    console.log('Inventory page initialized');
  };

  ns.inventoryInit = ns.inventory.init;
})(window.RockFlow);