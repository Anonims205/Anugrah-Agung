// charts.js - helper untuk membuat grafik menggunakan Chart.js
window.RockFlow = window.RockFlow || {};
(function(ns){
  ns.initCharts = function(){
    // Inisialisasi chart pergerakan stok (jika ada)
    var ctx = document.getElementById('stockMovementChart');
    if(!ctx) return;

    var data = ns.data && ns.data.stockMovement;
    if(!data) return;

    // Hapus chart sebelumnya jika ada
    if(ctx._rfChart){
      ctx._rfChart.destroy();
      ctx._rfChart = null;
    }

    ctx._rfChart = new Chart(ctx, {
      type: 'line',
      data: {
        labels: data.labels,
        datasets: [{
          label: 'Total Stok',
          data: data.values,
          borderColor: '#3498db',
          backgroundColor: 'rgba(52,152,219,0.12)',
          tension: 0.3,
          fill: true,
          pointRadius: 3
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: { display: false }
        },
        scales: {
          x: { display: true },
          y: { beginAtZero: true }
        }
      }
    });
  };

  // expose data ref
  ns.data = ns.data || window.RockFlow.data;
})(window.RockFlow);