// dashboard.js - logika halaman dashboard
window.RockFlow = window.RockFlow || {};
(function(ns){
  ns.dashboard = ns.dashboard || {};

  ns.dashboard.init = function(){
    // update total stock (contoh: jumlah produk)
    var total = (ns.data && ns.data.products) ? ns.data.products.length : 0;
    var el = document.getElementById('totalStock');
    if(el) el.textContent = total;

    // tampilkan daftar singkat produk di dashboard (optional)
    // inisialisasi grafik
    if(typeof ns.initCharts === 'function'){
      ns.initCharts();
    }
  };

  // expose
  ns.dashboardInit = ns.dashboard.init;
})(window.RockFlow);