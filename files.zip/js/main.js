// main.js - inisialisasi aplikasi RockFlow (global namespace)
window.RockFlow = window.RockFlow || {};

(function(ns){
  function showPage(pageId){
    document.querySelectorAll('.page').forEach(function(s){
      s.style.display = 'none';
    });
    var el = document.getElementById('page-' + pageId);
    if(el) el.style.display = 'block';

    // panggil inisialisasi page bila tersedia
    var initFn = ns[pageId] && ns[pageId].init;
    if(typeof initFn === 'function') initFn();
  }

  function wireNav(){
    document.querySelectorAll('.nav-page').forEach(function(a){
      a.addEventListener('click', function(e){
        e.preventDefault();
        document.querySelectorAll('.nav-page').forEach(n=>n.classList.remove('active'));
        this.classList.add('active');
        var page = this.getAttribute('data-page');
        showPage(page);
      });
    });
  }

  ns.init = function(){
    wireNav();
    // tampilkan dashboard default
    showPage('dashboard');
  };

  // jalankan saat DOM siap
  document.addEventListener('DOMContentLoaded', function(){
    ns.init();
  });

})(window.RockFlow);