// products.js - logika halaman produk
window.RockFlow = window.RockFlow || {};
(function(ns){
  ns.products = ns.products || {};

  ns.products.init = function(){
    var list = document.getElementById('productsList');
    if(!list) return;
    list.innerHTML = '';
    var data = ns.data && ns.data.products ? ns.data.products : [];
    data.forEach(function(p){
      var li = document.createElement('li');
      li.className = 'list-group-item d-flex justify-content-between align-items-center';
      li.innerHTML = '<div><strong>' + p.name + '</strong><br><small class="text-muted">' + p.sku + '</small></div>'
        + '<span class="badge bg-primary rounded-pill">Stok: ' + p.stock + '</span>';
      list.appendChild(li);
    });
  };

  // expose
  ns.productsInit = ns.products.init;
})(window.RockFlow);